# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
QaApp::Application.config.secret_token = '733f644246a6b9b5d84e41c1cd2dff2136643f7171b4ab4b8aa04549f99a186fe03969e6d348dc290b4c385795e8c395abc50c261e82d106a104117bb7a05b1b'
