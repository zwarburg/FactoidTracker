require 'test_helper'

class FactoidTest < ActiveSupport::TestCase

end
